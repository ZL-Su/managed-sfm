#pragma once

#ifdef ADOTEX_API_EXPORTS
#define ADOTEX_API __declspec(dllexport)
#else
#define ADOTEX_API __declspec(dllimport)
#endif