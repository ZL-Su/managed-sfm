#pragma once

#include "port.hpp"
#include <vector>
#include <opencv2/core.hpp>

ADOTEX_API std::vector<float_t> fit_plane(const std::vector<cv::Point3d>&);
ADOTEX_API std::vector<float_t> fit_cylin(const std::vector<cv::Point3d>&);
